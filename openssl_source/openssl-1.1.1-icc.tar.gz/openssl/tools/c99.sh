#!/bin/sh -k
#
# Re-order arguments so that -L comes first
#
opts=""
lopts=""
        
for arg in $* ; do
  case $arg in
    -L*) lopts="$lopts $arg" ;;
    *) opts="$opts $arg" ;;
  esac
  source=$arg;
done

#echo "source=$source"
filename=$(basename "$source")
#echo "filename=$filename"
extension="${filename##*.}"
#echo "$extension"

if [ "$filename" = "aes-s390x.s" ]; then
  cmdline="-Wa,SECTALGN(256) $lopts $opts";
elif [ "$filename" = "chacha-s390x.s" ]; then
  cmdline="-Wa,SECTALGN(32) $lopts $opts";
elif [ "$filename" = "ghash-s390x.s" ]; then
  cmdline="-Wa,SECTALGN(32) $lopts $opts";
elif [ "$filename" = "rc4-s390x.s" ]; then
  cmdline="-Wa,SECTALGN(64) $lopts $opts";
elif [ "$filename" = "keccak1600-s390x.s" ]; then
  cmdline="-Wa,SECTALGN(256) $lopts $opts";
else
#  echo "Default"
  cmdline="-Wl,dll $lopts $opts";
fi

#echo "c99 $cmdline"
c99 $cmdline

