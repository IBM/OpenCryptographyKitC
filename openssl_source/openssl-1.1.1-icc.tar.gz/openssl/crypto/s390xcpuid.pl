#! /usr/bin/env perl
# Copyright 2009-2018 The OpenSSL Project Authors. All Rights Reserved.
#
# Licensed under the OpenSSL license (the "License").  You may not use
# this file except in compliance with the License.  You can obtain a copy
# in the file LICENSE in the source distribution or at
# https://www.openssl.org/source/license.html


#
# Note to Jon. You need to update s390xcap.c s390x_arch.h to pick up the changes to  OPENSSL_s390xcap_P to cater for the longer
# capability vector and the split into facilities/functions
#
use strict;
use FindBin qw($Bin);
use lib "$Bin/../..";
use lib "$Bin/";
use perlasm::s390x qw(:DEFAULT :VX :LD :MSA :MSA4 :MSA5 :MSA8 stfle AUTOLOAD LABEL INCLUDE FUNCTION_BEGIN FUNCTION_END LONG ALIGN ASCIZ TEXT GET_EXTERN LOCAL_VARS_BEGIN LOCAL_VARS_END ds);

my $flavour = shift;
my ($z,$DSA_OFF,$PARMS_OFF,$SIZE_T);
my ($alwaysr0,$alwaysr1);
my ($fr0,$fr1,$fr2,$fr3,$fr4,$fr5,$fr6,$fr7,$ip,$ra,$sp,$v0,$wr0,$wr1,$wr2,$wr3,$wr4,$wr5,$wr6,$inp,$len,$rv);

$DSA_OFF=2048;
if ($flavour =~ /3[12]/) {
        $z=0;	# 31/32 bit ABI
		$SIZE_T=4;
        $PARMS_OFF=2112
} else {
        $z=1;	# 64 bit ABI
		$SIZE_T=8;
        $PARMS_OFF=2176
}

if ($flavour =~ /linux/) {
        $alwaysr0="%r0";
        $alwaysr1="%r1";
        $inp="%r2";
        $len="%r4";

        $fr0="%f0";
        $fr1="%f1";
        $fr2="%f2";
        $fr3="%f3";
        $fr4="%f4";
        $fr5="%f5";
        $fr6="%f6";
        $fr7="%f7";

        $v0="%v0";

        $wr0="%r0";
        $wr1="%r1";
        $wr2="%r2";
        $wr3="%r3";
        $wr4="%r4";
        $wr5="%r5";
        $wr6="%r6";
        
        $sp="%r15";
        $rv="%r2";
        $ra="%r14";
        $ip=".";
} else {
        $alwaysr0="R0";
        $alwaysr1="R1";

        $inp="R1";
        $len="R2";

        $fr0="f0";
        $fr1="f1";
        $fr2="f2";
        $fr3="f3";
        $fr4="f4";
        $fr5="f5";
        $fr6="f6";
        $fr7="f7";

        $v0="0";

        $wr0="R6";
        $wr1="R7";
        $wr2="R8";
        $wr3="R9";
        $wr4="R10";
        $wr5="R11";
        $wr6="R14";
        
        $sp="R4";
        $rv="R3";
        $ra="R7";

        $ip="*";
}

my $output;
while (($output=shift) && ($output!~/\w[\w\-]*\.\w+$/)) {}
open STDOUT,">$output";

my $stdframe=16*$SIZE_T+4*8;

#my $code=<<___;

PERLASM_BEGIN($flavour,$output);

INCLUDE	("s390x_arch.h", "crypto/");
TEXT	();
#include "s390x_arch.h"

################
# void OPENSSL_s390x_facilities(void)
{
#.text
#.globl	OPENSSL_s390x_facilities
#.type	OPENSSL_s390x_facilities,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_s390x_facilities",0,"","stor2");
	xgr	($alwaysr0,$alwaysr0); 
	GET_EXTERN($wr4,"OPENSSL_s390xcap_P");

	stg	($alwaysr0,"CS390X_STFLE+8($wr4)");	# wipe capability vectors
	stg	($alwaysr0,"CS390X_STFLE+16($wr4)");
	stg	($alwaysr0,"CS390X_STFLE+24($wr4)");
	stfle	("0($wr4)");
	brc	(8,LABEL("Ldone"));
	lghi	($alwaysr0,"1");
	stfle	("0($wr4)");
	brc	(8,LABEL("Ldone"));
	lghi	($alwaysr0,"2");
	stfle	("0($wr4)");
LABEL   ("Ldone:");
FUNCTION_END("OPENSSL_s390x_facilities",$rv);  
}
{
FUNCTION_BEGIN("OPENSSL_s390x_functions",0,"","stor2");
	lghi	($alwaysr0,0); 
	GET_EXTERN($wr4,"OPENSSL_s390xcap_P");

	stg	($alwaysr0,"CS390X_KIMD($wr4)");
	stg	($alwaysr0,"CS390X_KIMD+8($wr4)");
	stg	($alwaysr0,"CS390X_KLMD($wr4)");
	stg	($alwaysr0,"CS390X_KLMD+8($wr4)");
	stg	($alwaysr0,"CS390X_KM($wr4)");
	stg	($alwaysr0,"CS390X_KM+8($wr4)");
	stg	($alwaysr0,"CS390X_KMC($wr4)");
	stg	($alwaysr0,"CS390X_KMC+8($wr4)");
	stg	($alwaysr0,"CS390X_KMAC($wr4)");
	stg	($alwaysr0,"CS390X_KMAC+8($wr4)");
	stg	($alwaysr0,"CS390X_KMCTR($wr4)");
	stg	($alwaysr0,"CS390X_KMCTR+8($wr4)");
	stg	($alwaysr0,"CS390X_KMO($wr4)");
	stg	($alwaysr0,"CS390X_KMO+8($wr4)");
	stg	($alwaysr0,"CS390X_KMF($wr4)");
	stg	($alwaysr0,"CS390X_KMF+8($wr4)");
	stg	($alwaysr0,"CS390X_PRNO($wr4)");
	stg	($alwaysr0,"CS390X_PRNO+8($wr4)");
	stg	($alwaysr0,"CS390X_KMA($wr4)");
	stg	($alwaysr0,"CS390X_KMA+8($wr4)");
	stg ($alwaysr0,"CS390X_PCC($wr4)");
	stg	($alwaysr0,"CS390X_PCC+8($wr4)");
	stg	($alwaysr0,"CS390X_KDSA($wr4)");
	stg	($alwaysr0,"CS390X_KDSA+8($wr4)");



	lmg	    ($wr2,$wr3,"CS390X_STFLE($wr4)");
	tmhl	($wr2,"0x4000");	# check for message-security-assist
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");	# query kimd capabilities
	la	    ($alwaysr1,"CS390X_KIMD($wr4)");
	kimd    ($alwaysr0,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query klmd capabilities
	la	    ($alwaysr1,"CS390X_KLMD($wr4)");
	klmd    ($alwaysr0,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query km capability vector
	la	    ($alwaysr1,"CS390X_KM($wr4)");
	km      ($wr4,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query kmc capability vector
	la	    ($alwaysr1,"CS390X_KMC($wr4)");
	kmc     ($wr4,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query kmac capability vector
	la	    ($alwaysr1,"CS390X_KMAC($wr4)");
	kmac    ($wr4,$wr2);

	tmhh	($wr3,0x0008);		# check for message-security-assist-3
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");		# query pcc capability vector
	la	    ($alwaysr1,"CS390X_PCC($wr4)");
    LONG(0xb92c0000);
#	pcc     ($alwaysr0,$wr2);    #.long	0xb92c0000	(Unsure of this one)

	tmhh	($wr3,"0x0004");	# check for message-security-assist-4
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");	# query kmctr capability vector
	la	    ($alwaysr1,"CS390X_KMCTR($wr4)");
	kmctr   ($wr4,$wr2,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query kmo capability vector
	la	    ($alwaysr1,"CS390X_KMO($wr4)");
	kmo     ($wr4,$wr2);

	lghi	($alwaysr0,"CS390X_QUERY");	# query kmf capability vector
	la	    ($alwaysr1,"CS390X_KMF($wr4)");
	kmf     ($wr4,$wr2);

	tml	    ($wr2,"0x40");		# check for message-security-assist-5
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");	# query prno capability vector
	la	    ($alwaysr1,"CS390X_PRNO($wr4)");
	prno    ($wr4,$wr2);

	lg	    ($wr2,"CS390X_STFLE+16($wr4)");
	tmhl	($wr2,"0x2000");	# check for message-security-assist-8
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");	# query kma capability vector
	la	    ( $alwaysr1,"CS390X_KMA($wr4)");
	kma     ($wr2,$wr4,$wr2);

	tmhl	($wr2,0x0010);		# check for message-security-assist-9
	jz	    (LABEL("Lret"));

	lghi	($alwaysr0,"CS390X_QUERY");		# query kdsa capability vector
	la	    ($alwaysr1,"CS390X_KDSA($wr4)");
	LONG	(0xb93a0002);					# kdsa    ($alwaysr0,$wr2); 
LABEL   ("Lret:");
#	br	($ra);
#.size	OPENSSL_s390x_facilities,.-OPENSSL_s390x_facilities
FUNCTION_END("OPENSSL_s390x_functions",$rv);
}

################
# unsigned long OPENSSL_rdtsc(void)
# We can do this (better) in C on z/OS, so this is zLinux only
if ($flavour =~ /linux/)
{
my $clock;
if ($flavour =~ /linux/) {
    $clock="16($sp)";
} else {
    $clock="CLOCK";
} 
#.globl	OPENSSL_rdtsc
#.type	OPENSSL_rdtsc,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_rdtsc",0,"true","stor2");
	GET_EXTERN($wr4,"OPENSSL_s390xcap_P");
	tm	("CS390X_STFLE+3($wr4)","0x40");	# check for store-clock-fast facility
	jz	(LABEL("Lstck"));
    if($flavour =~ /linux/) {
        LONG(0xb27cf010); 
    } else {    
	    stckf   ("$clock");
    }    
	lg	($rv,"$clock");
	j	(LABEL("EXIT_OPENSSL_rdtsc"));
LABEL   ("Lstck:");
	stck	("$clock");
	lg	($rv,"$clock");
#.size	OPENSSL_rdtsc,.-OPENSSL_rdtsc
FUNCTION_END("OPENSSL_rdtsc",$rv);  
LOCAL_VARS_BEGIN();
	ds	("CLOCK", "XL16");
LOCAL_VARS_END();
}

################
# unsigned long OPENSSL_atomic_add(ulong *currentValue,ulong addend) <===best guess
{
my ($inp,$addend);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $addend="%r3";
} else {
    $inp="r1";
    $addend="r2";
}
#.globl	OPENSSL_atomic_add
#.type	OPENSSL_atomic_add,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_atomic_add",0);
        l	($wr1,"0($inp)");
LABEL   ("Lspin:");
	lr	($wr0,$wr1);
	ar	($wr0,$addend);
	cs	($wr1,$wr0,"0($inp)");
	brc	(4,LABEL("Lspin"));
	lgfr	($rv,$wr0);	# OpenSSL expects the new value
#.size	OPENSSL_atomic_add,.-OPENSSL_atomic_add
FUNCTION_END("OPENSSL_atomic_add",$rv);
}

################
# void OPENSSL_wipe_cpu(void)
{
#.globl	OPENSSL_wipe_cpu
#.type	OPENSSL_wipe_cpu,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_wipe_cpu",0);
	xgr	($wr0,$wr0);
	xgr	($wr1,$wr1);
	lgr	($wr2,$sp);
	xgr	($wr3,$wr3);
	xgr	($wr4,$wr4);
	lzdr	($fr0);
	lzdr	($fr1);
	lzdr	($fr2);
	lzdr	($fr3);
	lzdr	($fr4);
	lzdr	($fr5);
	lzdr	($fr6);
	lzdr	($fr7);
#.size	OPENSSL_wipe_cpu,.-OPENSSL_wipe_cpu
    FUNCTION_END("OPENSSL_wipe_cpu",$rv);
}

################
# void OPENSSL_cleanse(void *ptr, size_t len);
{
my ($inp,$len);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
} else {
    $inp="r1";
    $len="r2";
}
#.globl	OPENSSL_cleanse
#.type	OPENSSL_cleanse,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_cleanse",2);
&{$z? \&lgr:\&lr}    ($wr0,$inp);      # Move stor addr to MVCL target
&{$z? \&lgr:\&lr}    ($wr1,$len);      # Move stor len to MVCL target len     
#&{$z? \&xgr:\&xr}    ($w2,$wr2);       # Set MVCL source to 0 (not needed)
&{$z? \&xgr:\&xr}    ($wr3,$wr3);      # Set MVCL source pad and len to 0
        mvcl  ($wr0,$wr2);      # source pad and len 0, so storage cleared
##if !defined(__s390x__) && !defined(__s390x)
#	llgfr	($len,$len);
##endif
#	lghi	($wr4,15);
#	lghi	($wr0,0);
#	clgr	($len,$wr4);
#	jh	("Lot");
#	clgr	($len,$wr0);
#	bcr	(8,"EXIT_OPENSSL_cleanse");
#LABEL("Little");
#	stc	($wr0,"0($inp)");
#	la	($inp,"1($inp)");
#	brctg	($wr3,"Little");
#	br	("EXIT_OPENSSL_cleanse");
#ALIGN(4);
#LABEL("Lot");
#	tmll	($inp,7);
#	jz	("Laligned");
#	stc	($wr0,"0($inp)");
#	la	($inp,"1($inp)");
#	brctg	($len,"Lot");
#LABEL("Laligned");
#	srlg	($wr4,$wr3,3);
#LABEL("Loop");
#	stg	($wr0,"0($inp)");
#	la	($inp,"8($inp)");
#	brctg	($wr4,"Loop");
#	lghi	($wr4,7);
#	ngr	($len,$wr4);
#	jnz	("Little");
#	br	($ra);
#.size	OPENSSL_cleanse,.-OPENSSL_cleanse
        FUNCTION_END("OPENSSL_cleanse",$rv);
}

################
# int CRYPTO_memcmp(const void * in_a, const void * in_b, size_t len);
{
my ($inpa,$inpb,$len);
if ($flavour =~ /linux/) {
    $inpa="%r2";
    $inpb="%r3";
    $len="%r4";
} else {
    $inpa="r1";
    $inpb="r2";
    $len="r3";
}
#.globl	CRYPTO_memcmp
#.type	CRYPTO_memcmp,\@function
#.align	16    
FUNCTION_BEGIN("CRYPTO_memcmp",3);
#if !defined(__s390x__) && !defined(__s390x)
	llgfr	($len,$len);
#endif
	lghi	($wr5,0);
	clgr	($len,$wr5);
	je	(LABEL("Lno_data"));

LABEL("Loop_cmp:");
	llgc	($wr0,"0($inpa)");
	la	($inpa,"1($inpa)");
	llgc	($wr1,"0($inpb)");
	la	($inpb,"1($inpb)");
	xr	($wr1,$wr0);
	&or	($wr5,$wr1);
	brctg	($len,LABEL("Loop_cmp"));

	lnr	($wr5,$wr5);
	srl	($wr5,31);
LABEL("Lno_data:");
	lgr	($rv,$wr5);
#.size	CRYPTO_memcmp,.-CRYPTO_memcmp
    FUNCTION_END("OPENSSL_cleanse",$rv);
}

################
# size_t OPENSSL_instrument_bus(unsigned int *, size_t);
{
my ($inp,$len);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r4";
} else {
    $inp="r1";
    $len="r2";
}
#
#.globl	OPENSSL_instrument_bus
#.type	OPENSSL_instrument_bus,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_instrument_bus",2);
	lghi	($rv,0);
#.size	OPENSSL_instrument_bus,.-OPENSSL_instrument_bus
FUNCTION_END("OPENSSL_instrument_bus",$rv);
}

################
# size_t OPENSSL_instrument_bus2(unsigned int *, size_t, size_t);
{
my ($inp,$len);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r4";
} else {
    $inp="r1";
    $len="r2";
}
#
#.globl	OPENSSL_instrument_bus2
#.type	OPENSSL_instrument_bus2,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_instrument_bus2",3);
	lghi	($rv,0);
#.size	OPENSSL_instrument_bus2,.-OPENSSL_instrument_bus2
FUNCTION_END("OPENSSL_instrument_bus2",$rv);
}

################
# void OPENSSL_vx_probe(void);
{
#
#.globl	OPENSSL_vx_probe
#.type	OPENSSL_vx_probe,\@function
#.align	16
FUNCTION_BEGIN("OPENSSL_vx_probe",0);
        vzero ($v0);
#.size	OPENSSL_vx_probe,.-OPENSSL_vx_probe
FUNCTION_END("OPENSSL_vx_probe",$rv);
}

################
# void s390x_kimd(const unsigned char *in, size_t len, unsigned int fc,
#                 void *param)
{
my ($inp,$len,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
    $fc="%r4";
    $param="%r5";
} else {
    $inp="r1";
    $len="r2";
    $fc="r3";
}
#.globl	s390x_kimd
#.type	s390x_kimd,\@function
#.align	16
FUNCTION_BEGIN("s390x_kimd",4);
	llgfr	($alwaysr0,$fc);
if ($flavour =~ /linux/) {
	lgr	($wr1,$param);
} else {    
    # inp is in r1 - len is in r2 - fc is in r3 
    # param is in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move len to source register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*3($wr6)"); # Get param CB
}

	kimd    ($alwaysr0,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_kimd,.-s390x_kimd
FUNCTION_END("s390x_kimd",$rv);
}


{
################
# void s390x_klmd(const unsigned char *in, size_t inlen, unsigned char *out,
#                 size_t outlen, unsigned int fc, void *param)
my ($inp,$inlen,$outp,$outlen,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $inlen="%r3";
    $outp="%r4";
    $outlen="%r5";
    $fc="%r6";
    $param="%r7";
} else {
    $inp="r1";
    $inlen="r2";
    $outp="r3";
}
#$code.=<<___;
#.globl	s390x_klmd
#.type	s390x_klmd,\@function
#.align	32
FUNCTION_BEGIN("s390x_klmd",6);

if ($flavour =~ /linux/) {
    llgfr	("%r0",$fc);
&{$z? \&lg:\&l} ("%r1","$stdframe($sp)");
} else {

    # inp is in r1 - inlen is in r2 - out is in r3 
    # outlen, fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$inlen);           # Move inlen to source register
&{$z? \&lgr:\&lr}	($wr4,$outp);            # Move out to target register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	($wr5,"$PARMS_OFF+$SIZE_T*3($wr6)"); # Get out length
&{$z? \&lg:\&l} ("r0","$PARMS_OFF+$SIZE_T*4($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*5($wr6)"); # Get param CB
}
	klmd    ($wr4,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_klmd,.-s390x_klmd
FUNCTION_END("s390x_klmd",$rv);
#___
}

################
# void s390x_km(const unsigned char *in, size_t len, unsigned char *out,
#               unsigned int fc, void *param)
{
my ($inp,$len,$outp,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
    $outp="%r4";
    $fc="%r5";
    $param="%r6";
} else {
    $inp="r1";
    $len="r2";
    $outp="r3";
}
#$code.=<<___;
#.globl	s390x_km
#.type	s390x_km,\@function
#.align	16
FUNCTION_BEGIN("s390x_km",5);
if ($flavour =~ /linux/) {
	lr	("%r0",$fc);
&{$z? \&lgr:\&lr} ("%r1",$param);

} else {
    # inp is in r1 - len is in r2 - out is in r3 
    # fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move len to source register
&{$z? \&lgr:\&lr}	($wr4,$outp);            # Move out to target register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l} ("r0","$PARMS_OFF+$SIZE_T*3($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*4($wr6)"); # Get param CB
}

	km      ($wr4,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_km,.-s390x_km
FUNCTION_END("s390x_km",$rv);
#___
}

################
# void s390x_kmac(const unsigned char *in, size_t len, unsigned int fc,
#                 void *param)
{
my ($inp,$len,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
    $fc="%r4";
    $param="%r5";
} else {
    $inp="r1";
    $len="r2";
    $fc="r3";
}
#$code.=<<___;
#.globl	s390x_kmac
#.type	s390x_kmac,\@function
#.align	16
FUNCTION_BEGIN("s390x_kmac",4);
LABEL("s390x_kmac_A:");
        lr	($alwaysr0,$fc); # Get function code
if ($flavour =~ /linux/) {
&{$z? \&lgr:\&lr} ("%r1",$param);

} else {
    # inp is in r1 - len is in r2 - fc is in r3 
    # param is in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move len to source register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*3($wr6)"); # Get param CB
}

	kmac    ($alwaysr0,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_kmac,.-s390x_kmac
FUNCTION_END("s390x_kmac",$rv);
#___
}

################
# void s390x_kmo(const unsigned char *in, size_t len, unsigned char *out,
#                unsigned int fc, void *param)
{
my ($inp,$len,$outp,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
    $outp="%r4";
    $fc="%r5";
    $param="%r6";
} else {
    $inp="r1";
    $len="r2";
    $outp="r3";
}
#$code.=<<___;
#.globl	s390x_kmo
#.type	s390x_kmo,\@function
#.align	16
FUNCTION_BEGIN("s390x_kmo",5);
if ($flavour =~ /linux/) {
	lr	("%r0",$fc);
&{$z? \&lgr:\&lr} ("%r1",$param);

} else {
    # inp is in r1 - len is in r2 - out is in r3 
    # fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move len to source register
&{$z? \&lgr:\&lr}	($wr4,$outp);            # Move out to target register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	("r0","$PARMS_OFF+$SIZE_T*3($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*4($wr6)"); # Get param CB
}

	kmo     ($wr4,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_kmo,.-s390x_kmo
FUNCTION_END("s390x_kmo",$rv);
#___
}

################
# void s390x_kmf(const unsigned char *in, size_t len, unsigned char *out,
#                unsigned int fc, void *param)
{
my ($inp,$len,$outp,$fc,$param);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
    $outp="%r4";
    $fc="%r5";
    $param="%r6";
} else {
    $inp="r1";
    $len="r2";
    $outp="r3";
}
#$code.=<<___;
#.globl	s390x_kmf
#.type	s390x_kmf,\@function
#.align	16
FUNCTION_BEGIN("s390x_kmf",5);

if ($flavour =~ /linux/) {
	lr	("%r0",$fc);
&{$z? \&lgr:\&lr} ("%r1",$param);

} else {
    # inp is in r1 - len is in r2 - out is in r3 
    # fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move len to source register
&{$z? \&lgr:\&lr}	($wr4,$outp);            # Move out to target register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l} ("r0","$PARMS_OFF+$SIZE_T*3($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*4($wr6)"); # Get param CB
}
	kmf     ($wr4,$wr2);
	brc	(1,"$ip-4");	# pay attention to "partial completion"

#.size	s390x_kmf,.-s390x_kmf
FUNCTION_END("s390x_kmf",$rv);
#___
}

################
# void s390x_kma(const unsigned char *aad, size_t alen,
#                const unsigned char *in, size_t len,
#                unsigned char *out, unsigned int fc, void *param)
{
my ($aad,$alen,$inp,$len,$outp);
if ($flavour =~ /linux/) {
    $aad="%r2";
    $alen="%r3";
    $inp="%r4";
    $len="%r5";
    $outp="%r6";
} else {
    $aad="r1";
    $alen="r2";
    $inp="r3";
}
#$code.=<<___;
#.globl	s390x_kma
#.type	s390x_kma,\@function
#.align	16
FUNCTION_BEGIN("s390x_kma",7);

if ($flavour =~ /linux/) {

&{$z? \&stg:\&st} ($outp,"6*$SIZE_T($sp)");
&{$z? \&lmg:\&lm} ("%r0","%r1","$stdframe($sp)");
	kma     ($outp,$aad,$inp);
	brc	(1,"$ip-4");    # pay attention to "partial completion"

&{$z? \&lg:\&l}	($outp,"6*$SIZE_T($sp)");

} else {
    # aad is in r1, alen is in r2, inp is in r3 
    # len, out, fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr0,$aad);             # Move aad
&{$z? \&lgr:\&lr}	($wr1,$alen);            # Move alen
&{$z? \&lgr:\&lr}	($wr2,$inp);             # Move inp to source register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	($wr3,"$PARMS_OFF+$SIZE_T*3($wr6)"); # Move len to source register
&{$z? \&lg:\&l}	($wr4,"$PARMS_OFF+$SIZE_T*4($wr6)"); # Move out to target register
&{$z? \&lg:\&l}	("r0","$PARMS_OFF+$SIZE_T*5($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*6($wr6)"); # Get param CB
	kma     ($wr4,$wr0,$wr2);
	brc	(1,"$ip-4");    # pay attention to "partial completion"
}

#.size	s390x_kma,.-s390x_kma
FUNCTION_END("s390x_kma",$rv);

#___
}

{
###############
# int s390x_pcc(unsigned int fc, void *param)
my ($fc,$param);
if ($flavour =~ /linux/) {
    $fc="%r2";
    $param="%r3";
} else {
    $fc="r1";
    $param="r2";
}


FUNCTION_BEGIN("s390x_pcc",2);
	lr	    ($alwaysr0,$fc);
	&{$z? \&lgr:\&lr}	($alwaysr1,$param); # inplicitly used by pcc
	lhi	    ($rv,0);
	LONG	(0xb92c0000);	# pcc
	brc	    (1,"$ip-4");		# pay attention to "partial completion"
	brc	    (7,LABEL("Lpcc_err"));	# if CC==0 return 0, else return 1
    j       (LABEL("EXIT_s390x_pcc"));
LABEL("Lpcc_err:");
	lhi	    ($rv,1);
FUNCTION_END("s390x_pcc",$rv);

}

################
# int s390x_kdsa(unsigned int fc, void *param, const unsigned char *in, size_t len)
{
    my ($fc,$param,$in,$len);
    if ($flavour =~ /linux/) {
        $fc="%r2";
        $param="%r3";
        $in="%r4";
        $len="%r5";
    } else {
        $fc="r1";
        $param="r2";
        $in = "r3";
        # Other arguments on the stack on zOS
    }   
#
# int s390x_kdsa(unsigned int fc, void *param, const unsigned char *in, size_t len);
# 
FUNCTION_BEGIN("s390x_kdsa",4);        
        lr          ($alwaysr0,"$fc");
        &{$z? \&lgr:\&lr} ($alwaysr1,$param); # implicitly used by the kdsa instruction
if ($flavour =~ /linux/) {      
        xgr     ($rv,$rv);              # set rv to 0
        LONG    (0xb93a0004);           # kdsa    ($wr0,$in);
} else {
        &{$z? \&lgr:\&lr} ("R6","R3");          # Move $inp into even-odd reg pair
        xgr     ($rv,$rv);                      # set rv to 0
        &{$z? \&lg:\&l} ("R14","$DSA_OFF($sp)");      # Get DSA address
        &{$z? \&lg:\&l} ("R7","$PARMS_OFF+$SIZE_T*3(R14)"); # Get len
        LONG    (0xb93a0006);           # kdsa    ($wr0,$in);
}
        brc         (1,"$ip-4");                # pay attention to "partial completion"
        brc         (7,LABEL("Lkdsa_err"));     # if CC==0 return 0, else return 1
        j       (LABEL("EXIT_s390x_kdsa"));
LABEL("Lkdsa_err:");
        lhi         ($rv,1);
FUNCTION_END("s390x_kdsa",$rv);

}
################
# void s390x_trng(unsigned long long *	x,int i);
{
my ($inp,$len);
if ($flavour =~ /linux/) {
    $inp="%r2";
    $len="%r3";
} else {
    $inp="r1";
    $len="r2";
}
#$code.=<<___;
#.globl s390x_trng
#.type  s390x_trng,\@function
#.align 16
FUNCTION_BEGIN("s390x_trng",2);
if ($flavour !~ /linux/) {
&{$z? \&lgr:\&lr}	($wr2,$inp);  # Move inp to source
&{$z? \&lgr:\&lr}	($wr3,$len);  # Move len to source
}
       xgr     ($wr5,$wr5);       # Set length of output to 0, output addr not used
       lghi    ($alwaysr0,114);      # prno capability vector checked by caller
       prno    ($wr4,$wr2);
       brc     (1,"$ip-4");    # pay attention to "partial completion"
#.size  s390x_trng,.-s390x_trng
FUNCTION_END("s390x_trng",$rv);
}

################
# void s390x_drng( 6 parms? - in?, inlen?, out?, outlen?, unsigned int fc, void *param);
{
my ($outp,$outlen,$inp,$inlen,$fc);
if ($flavour =~ /linux/) {
    $outp="%r2";
    $outlen="%r3";
    $inp="%r4";
    $inlen="%r5";
    $fc="%r6";
} else {
    $outp="r1";
    $outlen="r2";
    $inp="r3";
}
#
#.globl s390x_drng
#.type  s390x_drng,\@function
#.align 16
FUNCTION_BEGIN("s390x_drng",2);
##if !defined(__s390x__) && !defined(__s390x)
#       l       %r1,96(%r15)
##else
#       lg      %r1,160(%r15)
##endif

if ($flavour =~ /linux/) {
&{$z? \&lg:\&l}	("%r1","$stdframe(%r15)");
       lr      ("%r0","%r6");   # prno capability vector checked by caller

} else {
    # outp is in r1 - outlen is in r2 - inp is in r3 
    # inlen, fc and param are in DSA
&{$z? \&lgr:\&lr}	($wr2,$outp);            # Move outp to target register
&{$z? \&lgr:\&lr}	($wr3,$len);             # Move outlen to target register
&{$z? \&lgr:\&lr}	($wr4,$inp);             # Move inp to source register
&{$z? \&lg:\&l} ($wr6,"$DSA_OFF($sp)");      # Get DSA address
&{$z? \&lg:\&l}	($wr5,"$PARMS_OFF+$SIZE_T*3($wr6)"); # Get inlen
&{$z? \&lg:\&l}	("r0","$PARMS_OFF+$SIZE_T*4($wr6)"); # Get function code
&{$z? \&lg:\&l}	("r1","$PARMS_OFF+$SIZE_T*5($wr6)"); # Get param CB
}

       prno    ($wr2,$wr4);
       brc     (1,"$ip-4");     # pay attention to "partial completion"
#.size  s390x_drng,.-s390x_drng
FUNCTION_END("s390x_drng",$rv);
}

# These next two won't work on z/OS at this point in time.
################
# void s390x_flip_endian32(unsigned char dst[32], const unsigned char src[32])
{

my ($dst,$src, @temp);
if ($flavour =~ /linux/) {
    $dst="%r2";
    $src = "%r3";
    @temp = ("%r0", "%r1", "%r4", "%r5");
} else {
    $dst = "R1";
    $src = "R2";
    @temp = ("R0", "R3", "R5", "R6");
}


FUNCTION_BEGIN("s390x_flip_endian32",2);
        lrvg    ("@temp[0]","0($src)");
        lrvg    ("@temp[1]","8($src)");
        lrvg    ("@temp[2]","16($src)");
        lrvg    ("@temp[3]","24($src)");
        stg     ("@temp[1]","16($dst)");
        stg     ("@temp[2]","8($dst)");
        stg     ("@temp[0]","24($dst)");
        stg     ("@temp[3]","0($dst)");
FUNCTION_END("s390x_flip_endian32",$rv);

}
################
# void s390x_flip_endian64(unsigned char dst[64], const unsigned char src[64])
# Note that this is done in two halves
# 1) Avoid having to push & pop registers
# 2) Avoid register load/store interlocks as much as is possible
{
my ($dst,$src, @temp);
if ($flavour =~ /linux/) {
    $dst="%r2";
    $src = "%r3";
    @temp = ("%r0", "%r1", "%r4", "%r5");
} else {
    $dst = "R1";
    $src = "R2";
    @temp = ("R0", "R3", "R5", "R6");
}


FUNCTION_BEGIN("s390x_flip_endian64",2);
#        stmg    %r6,%r9,6*$SIZE_T($sp)

        lrvg    ("@temp[0]","0($src)");
        lrvg    ("@temp[1]","56($src)");
        lrvg    ("@temp[2]","16($src)");
        lrvg    ("@temp[3]","40($src)");

        stg     ("@temp[0]","56($dst)");
        stg     ("@temp[1]","0($dst)");
        stg     ("@temp[2]","40($dst)");
        stg     ("@temp[3]","16($dst)");

        lrvg    ("@temp[0]","8($src)");
        lrvg    ("@temp[1]","48($src)");
        lrvg    ("@temp[2]","24($src)");
        lrvg    ("@temp[3]","32($src)");

        stg     ("@temp[0]","48($dst)");
        stg     ("@temp[1]","8($dst)");
        stg     ("@temp[2]","32($dst)");
        stg     ("@temp[3]","24($dst)");

#        lmg     %r6,%r9,6*$SIZE_T($sp)

FUNCTION_END("s390x_flip_endian64",$rv);
}


PERLASM_END();
