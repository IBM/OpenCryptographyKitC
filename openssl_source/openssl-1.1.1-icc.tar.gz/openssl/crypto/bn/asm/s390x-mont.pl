#! /usr/bin/env perl
# Copyright 2007-2018 The OpenSSL Project Authors. All Rights Reserved.
#
# Licensed under the OpenSSL license (the "License").  You may not use
# this file except in compliance with the License.  You can obtain a copy
# in the file LICENSE in the source distribution or at
# https://www.openssl.org/source/license.html


# ====================================================================
# Written by Andy Polyakov <appro@openssl.org> for the OpenSSL
# project. The module is, however, dual licensed under OpenSSL and
# CRYPTOGAMS licenses depending on where you obtain it. For further
# details see http://www.openssl.org/~appro/cryptogams/.
# ====================================================================

# April 2007.
#
# Performance improvement over vanilla C code varies from 85% to 45%
# depending on key length and benchmark. Unfortunately in this context
# these are not very impressive results [for code that utilizes "wide"
# 64x64=128-bit multiplication, which is not commonly available to C
# programmers], at least hand-coded bn_asm.c replacement is known to
# provide 30-40% better results for longest keys. Well, on a second
# thought it's not very surprising, because z-CPUs are single-issue
# and _strictly_ in-order execution, while bn_mul_mont is more or less
# dependent on CPU ability to pipe-line instructions and have several
# of them "in-flight" at the same time. I mean while other methods,
# for example Karatsuba, aim to minimize amount of multiplications at
# the cost of other operations increase, bn_mul_mont aim to neatly
# "overlap" multiplications and the other operations [and on most
# platforms even minimize the amount of the other operations, in
# particular references to memory]. But it's possible to improve this
# module performance by implementing dedicated squaring code-path and
# possibly by unrolling loops...

# January 2009.
#
# Reschedule to minimize/avoid Address Generation Interlock hazard,
# make inner loops counter-based.

# November 2010.
#
# Adapt for -m31 build. If kernel supports what's called "highgprs"
# feature on Linux [see /proc/cpuinfo], it's possible to use 64-bit
# instructions and achieve "64-bit" performance even in 31-bit legacy
# application context. The feature is not specific to any particular
# processor, as long as it's "z-CPU". Latter implies that the code
# remains z/Architecture specific. Compatibility with 32-bit BN_ULONG
# is achieved by swapping words after 64-bit loads, follow _dswap-s.
# On z990 it was measured to perform 2.6-2.2 times better than
# compiler-generated code, less for longer keys...

use strict;
use FindBin qw($Bin);
use lib "$Bin/../..";
use perlasm::s390x qw(:MSA :DEFAULT :VX :LD AUTOLOAD LABEL INCLUDE FUNCTION_BEGIN FUNCTION_END OBJECT_BEGIN OBJECT_END BYTE LONG QUAD ALIGN ASCIZ TEXT GET_EXTERN LOCAL_VARS_BEGIN LOCAL_VARS_END BR_EXIT ds);

my ($flavour,$output,$SIZE_T,$z,$stdframe,$sp);
my ($mn0,$mn1,$rp,$ap,$bp,$np,$n0);
my ($bi,$j,$ahi,$alo,$nhi,$nlo,$AHI,$NHI,$count,$num);
my ($DSA_OFF,$PARMS_OFF);
my ($wr0,$wr1,$wr8,$rv);
$flavour = shift;

$DSA_OFF=2048;
if ($flavour =~ /3[12]/) {
	$SIZE_T=4;
	$z = 0;  # 31/32 bit ABI
	$PARMS_OFF=2112;
} else {
	$SIZE_T=8;
	$z=1;    # 64 bit ABI
	$PARMS_OFF=2176;
}

while (($output=shift) && ($output!~/\w[\w\-]*\.\w+$/)) {}
open STDOUT,">$output";

PERLASM_BEGIN($flavour,$output);

if($flavour =~/linux/ ) {
	$stdframe=16*$SIZE_T+4*8;

	$mn0="%r0";	$wr0="%r0";
	$num="%r1";

# int bn_mul_mont(
	$rp="%r2";		# BN_ULONG *rp,
	$ap="%r3";		# const BN_ULONG *ap,
	$bp="%r4";		# const BN_ULONG *bp,
	$np="%r5";		# const BN_ULONG *np,
	$n0="%r6";		# const BN_ULONG *n0,
#$num="160(%r15)"	# int num);
	
	$rv="%r2";	$bi="%r2";	# zaps rp
	$j="%r7";

	$ahi="%r8";
	$alo="%r9";
	$nhi="%r10";
	$nlo="%r11";
	$AHI="%r12";
	$NHI="%r13";
	$count="%r14";
	$sp="%r15";
} else {
	$stdframe=16*$SIZE_T+4*8;

	$mn0="R0";	$wr0="R0";
	$num="R1";

# int bn_mul_mont(
	$rp="R2";		# BN_ULONG *rp,
	$ap="R3";		# const BN_ULONG *ap,
	$bp="R4";		# const BN_ULONG *bp,
	$np="R5";		# const BN_ULONG *np,  	Passed in DSA
	$n0="R6";		# const BN_ULONG *n0,  	Passed in DSA
#$num="160(%r15)"	# int num);				Passed in DSA

	$bi="R2";	# zaps rp
	$rv="R2";
	$j="R7";

	$ahi="R8";
	$alo="R9";
	$nhi="R10";
	$nlo="R11";
	$AHI="R12";
	$NHI="R13";
	$count="R14";
	$sp="R15";
}
sub _dswap {
	my $reg = shift;
	if(($flavour =~ /linux/) && ($z == 0)) {
		rllg ($reg,$reg,32);
	}
}	
# int bn_mul_mont(BN_ULONG *rp,const BN_ULONG *ap,const BN_ULONG *bp,const BN_ULONG *np,const BN_ULONG *n0,int num);
	TEXT();
	FUNCTION_BEGIN("bn_mul_mont",6,"true");
	
# load parameters not passed in registers
if ($flavour =~ /linux/) {
	lgf		($num,"$stdframe+$SIZE_T-4($sp)");	# pull $num
} else {
  	la      ($sp,"STACK");		# Setup stack for z/OS

	&{$z? \&lg:\&l} ("R9","$DSA_OFF(R4)");     			# Get callers DSA address
  	
  	&{$z? \&stg:\&st} ("R4","0*$SIZE_T($sp)");			# save DSA on stack
  	&{$z? \&lgr:\&lr} ("R8","R3");						# Move bp into R8 and later into $bp which will corrupt the DSA (R4)
  	&{$z? \&lgr:\&lr} ($ap,"R2");						# Move ap into $ap
  	&{$z? \&lgr:\&lr} ($rp,"R1");						# Move rp into $rp
  	
  	&{$z? \&lg:\&l} ($np,"$PARMS_OFF+$SIZE_T*3(R9)");	# Get np address
  	&{$z? \&lg:\&l} ($n0,"$PARMS_OFF+$SIZE_T*4(R9)");	# Get n0 address
  	&{$z? \&lg:\&l} ($num,"$PARMS_OFF+$SIZE_T*5(R9)");	# Get num
}	
	
if ($flavour =~ /linux/) {
	sla		($num,eval "log($SIZE_T)/log(2)");	# $num to enumerate bytes   jpf - change this to SIZE_T for 8 byte BN_ULONG
	la		($bp,"0($num,$bp)");
} else {
	sla		($num,eval "log(8)/log(2)");	# $num to enumerate bytes   jpf - change this to SIZE_T for 8 byte BN_ULONG
	la		("R8","0($num,R8)");	# Don't corrupt DSA pointer before branches below
}

	&{$z? \&stg:\&st}	($rp,"2*$SIZE_T($sp)");	# save rp

	cghi	($num,16);		#
	lghi	($rv,0);		# Set return code - linux shares r2 with $rp, zos shares r3 with $ap
	BR_EXIT("l");			# if($num<16) return 0;

if ($flavour =~ /3[12]/) {
	tmll	($num,4);
	BR_EXIT("nz");			# if ($num&1) return 0;
} else {
	cghi	($num,96);		#
	BR_EXIT("h");			# if($num>96) return 0;
}

	lgr     ($bp,"R8") if ($flavour !~ /linux/);	# This corrupts DSA pointer (R4) 		
if ($flavour =~ /linux/) {
	&{$z? \&stmg:\&stm}	("%r3","%r15","3*$SIZE_T($sp)");
} else {
	&{$z? \&stmg:\&stm}	("R3","R4","3*$SIZE_T($sp)");
}

	lghi	($rp,-$stdframe-8);	# leave room for carry bit
	lcgr	($j,$num);		# -$num
	lgr		($wr0,$sp);
	la		($rp,"0($rp,$sp)");	# restore value overwritten by $rv
	la		($sp,"0($j,$rp)");	# alloca
	&{$z? \&stg:\&st }	($wr0,"0($sp)");	# back chain

	sra		($num,3);		# restore $num      jpf - Above we sla of 2 for 32 bit and 3 for 64 bit...bug
	la		($bp,"0($j,$bp)");	# restore $bp
	ahi		($num,-1);		# adjust $num for inner loop
	lg		($n0,"0($n0)");	# pull n0                                   jpf - need to clear high bits
	_dswap	($n0);

	lg		($bi,"0($bp)");
	_dswap	($bi);
	lg		($alo,"0($ap)");
	_dswap	($alo);
	mlgr	($ahi,$bi);		# ap[0]*bp[0]
	lgr		($AHI,$ahi);

	lgr		($mn0,$alo);	# "tp[0]"*n0
	msgr	($mn0,$n0);
	
	lg		($nlo,"0($np)");	#
	_dswap	($nlo);
	mlgr	($nhi,$mn0);	# np[0]*m1
	algr	($nlo,$alo);	# +="tp[0]"
	lghi	($NHI,0);
	alcgr	($NHI,$nhi);

	la		($j,"8($wr0)");	# j=1
	lr		($count,$num);

	ALIGN(16) if ($flavour =~ /linux/);
LABEL("L1st:");
	lg		($alo,"0($j,$ap)");
	_dswap	($alo);
	mlgr	($ahi,$bi);		# ap[j]*bp[0]
	algr	($alo,$AHI);
	lghi	($AHI,0);
	alcgr	($AHI,$ahi);

	lg		($nlo,"0($j,$np)");
	_dswap	($nlo);
	mlgr	($nhi,$mn0);	# np[j]*m1
	algr	($nlo,$NHI);
	lghi	($NHI,0);
	alcgr	($nhi,$NHI);	# +="tp[j]"
	algr	($nlo,$alo);
	alcgr	($NHI,$nhi);

	stg		($nlo,"$stdframe-8($j,$sp)");	# tp[j-1]=
	la		($j,"8($j)");	# j++
	brct	($count,LABEL("L1st"));

	algr	($NHI,$AHI);
	lghi	($AHI,0);
	alcgr	($AHI,$AHI);	# upmost overflow bit
	stg		($NHI,"$stdframe-8($j,$sp)");
	stg		($AHI,"$stdframe($j,$sp)");
	la		($bp,"8($bp)");	# bp++

LABEL("Louter:");
	lg		($bi,"0($bp)");		# bp[i]
	_dswap	($bi);
	lg		($alo,"0($ap)");
	_dswap	($alo);
	mlgr	($ahi,$bi);			# ap[0]*bp[i]
	alg		($alo,"$stdframe($sp)");	# +=tp[0]
	lghi	($AHI,0);
	alcgr	($AHI,$ahi);

	lgr		($mn0,$alo);
	msgr	($mn0,$n0);			# tp[0]*n0

	lg		($nlo,"0($np)");	# np[0]
	_dswap	($nlo);
	mlgr	($nhi,$mn0);		# np[0]*m1
	algr	($nlo,$alo);		# +="tp[0]"
	lghi	($NHI,0);
	alcgr	($NHI,$nhi);

	la		($j,"8($wr0)");		# j=1
	lr		($count,$num);

	ALIGN(16) if ($flavour =~ /linux/);
LABEL("Linner:");
	lg		($alo,"0($j,$ap)");
	_dswap	($alo);
	mlgr	($ahi,$bi);	# ap[j]*bp[i]
	algr	($alo,$AHI);
	lghi	($AHI,0);
	alcgr	($ahi,$AHI);
	alg		($alo,"$stdframe($j,$sp)"); # +=tp[j]
	alcgr	($AHI,$ahi);

	lg		($nlo,"0($j,$np)");
	_dswap	($nlo);
	mlgr	($nhi,$mn0);	# np[j]*m1
	algr	($nlo,$NHI);
	lghi	($NHI,0);
	alcgr	($nhi,$NHI);
	algr	($nlo,$alo);	# +="tp[j]"
	alcgr	($NHI,$nhi);

	stg		($nlo,"$stdframe-8($j,$sp)");	# tp[j-1]=
	la		($j,"8($j)");	# j++
	brct	($count,LABEL("Linner"));

	algr	($NHI,$AHI);
	lghi	($AHI,0);
	alcgr	($AHI,$AHI);
	alg		($NHI,"$stdframe($j,$sp)");# accumulate previous upmost overflow bit
	lghi	($ahi,0);
	alcgr	($AHI,$ahi);	# new upmost overflow bit
	stg		($NHI,"$stdframe-8($j,$sp)");
	stg		($AHI,"$stdframe($j,$sp)");

	la		($bp,"8($bp)");	# bp++
	&{$z? \&clg:\&cl}	($bp,"$stdframe+8+4*$SIZE_T($j,$sp)");	# compare to &bp[num]
	jne	(LABEL("Louter"));

	&{$z ? \&lg : \&l}	($rp,"$stdframe+8+2*$SIZE_T($j,$sp)");	# reincarnate rp
	la		($ap,"$stdframe($sp)");
	ahi	($num,1);		# restore $num, incidentally clears "borrow"

	la		($j,"0($wr0)");
	lr		($count,$num);
LABEL("Lsub:");	
	lg		($alo,"0($j,$ap)");
	lg		($nlo,"0($j,$np)");
	_dswap($nlo);
	slbgr	($alo,$nlo);
	stg		($alo,"0($j,$rp)");
	la		($j,"8($j)");
	brct	($count,LABEL("Lsub"));
	lghi	($ahi,0);
	slbgr	($AHI,$ahi);	# handle upmost carry
	lghi	($NHI,-1);
	xgr		($NHI,$AHI);

	la		($j,"0($wr0)");
	lgr		($count,$num);
LABEL("Lcopy:");	
	lg		($ahi,"$stdframe($j,$sp)");	# conditional copy
	lg		($alo,"0($j,$rp)");
	ngr		($ahi,$AHI);
	ngr		($alo,$NHI);
	ogr		($alo,$ahi);
	_dswap($alo);
	stg		($j,"$stdframe($j,$sp)");	# zap tp
	stg		($alo,"0($j,$rp)");
	la		($j,"8($j)");
	brct	($count,LABEL("Lcopy"));

if ($flavour =~ /linux/) {
	la		("%r1","$stdframe+8+6*$SIZE_T($j,$sp)");
	&{$z?\&lmg:\&lm} 	("%r6","%r15","0(%r1)");
} else {
	&{$z ? \&lg : \&l}	("R4","$stdframe+8+0*$SIZE_T($j,$sp)");	 # reload DSA pointer, other regs will be restored by exit macro
}	
	lghi	($rv,1);		# signal "processed"
	FUNCTION_END("bn_mul_mont", $rv);

	ASCIZ	("Montgomery Multiplication for s390x, CRYPTOGAMS by <appro\@openssl.org>");


#foreach (split("\n",$code)) {
#	s/\`([^\`]*)\`/eval $1/ge;
#	s/_dswap\s+(%r[0-9]+)/sprintf("rllg\t%s,%s,32",$1,$1) if($SIZE_T==4)/e;
#	print $_,"\n";
#}

LOCAL_VARS_BEGIN();
	ds		("STACKSPACE","400F");
    ds		("STACK", "0F");
    ds      ("SAVEAREA","32F");
LOCAL_VARS_END();
PERLASM_END();

