#! /usr/bin/env perl
# Copyright 2016 The OpenSSL Project Authors. All Rights Reserved.
#
# Licensed under the OpenSSL license (the "License").  You may not use
# this file except in compliance with the License.  You can obtain a copy
# in the file LICENSE in the source distribution or at
# https://www.openssl.org/source/license.html

#
# ====================================================================
# Written by Andy Polyakov <appro@openssl.org> for the OpenSSL
# project. The module is, however, dual licensed under OpenSSL and
# CRYPTOGAMS licenses depending on where you obtain it. For further
# details see http://www.openssl.org/~appro/cryptogams/.
# ====================================================================
#
# This module implements Poly1305 hash for s390x.
#
# June 2015
#
# ~6.6/2.3 cpb on z10/z196+, >2x improvement over compiler-generated
# code. For older compiler improvement coefficient is >3x, because
# then base 2^64 and base 2^32 implementations are compared.
#
# On side note, z13 enables vector base 2^26 implementation...

use strict;
use FindBin qw($Bin);
use lib "$Bin/../..";
use perlasm::s390x qw(:DEFAULT :LD :GE :EI :MI1 :VX AUTOLOAD LABEL INCLUDE LONG FUNCTION_BEGIN LOCAL_FUNCTION FUNCTION_END LOCAL_FUNCTION_END OBJECT_BEGIN OBJECT_END ALIGN ASCIZ TEXT GET_EXTERN LOCAL_VARS_BEGIN LOCAL_VARS_END BR_EXIT ds);

my $flavour = shift;

my ($z,$DSA_OFF,$PARMS_OFF,$SIZE_T);
$DSA_OFF=2048;
if ($flavour =~ /3[12]/) {
        $z=0;   # 31/32 bit ABI
        $SIZE_T=4;
        $PARMS_OFF=2112;
} else {
        $z=1;   # 64 bit ABI
        $SIZE_T=8;
        $PARMS_OFF=2176;
}

my $output;
while (($output=shift) && ($output!~/\w[\w\-]*\.\w+$/)) {}

my $stdframe=16*$SIZE_T+4*8;
my ($r0,$r1,$r10,$r15);
my ($sp,$ra,$rv);

my ($ctx,$inp,$len,$padbit);
if ($flavour =~ /linux/) {
        ($ctx,$inp,$len,$padbit) = map("%r$_",(2..5));
        
        ($r0,$r1,$r10,$r15) = map("%r$_",(0..1,10,15));
        $ra="%r14";
        $sp="%r15";
        $rv = "%r2";
} else {
        ($ctx,$inp,$len,$padbit) = map("R$_",(2..5));
        
        ($r0,$r1,$r10,$r15) = map("R$_",(0..1,10,15));
        $ra="R14";
        $sp="R15";
        $rv="R2";
}

PERLASM_BEGIN($flavour,$output);

INCLUDE ("s390x_arch.h","crypto/");
TEXT    ();

{
my ($ctx,$inp,$rv);
my ($wr1,$wr2,$wr3);

if ($flavour =~ /linux/) {
        $ctx="%r2";
        $inp="%r3";
        
        ($wr1,$wr2,$wr3) = map("%r$_",(1,4,5));
        $rv="%r2";
} else {
        $ctx="R1";
        $inp="R2";

        ($wr1,$wr2,$wr3) = map("R$_",(7..9));
        $rv="R3";
}


# int poly1305_init(void *ctx, const unsigned char key[16]);

FUNCTION_BEGIN("poly1305_init",2);   # 2 parms, no local storage
	lghi	($r0,0);
	lghi	($wr1,-1);
	stg	($r0,"0($ctx)");		# zero hash value
	stg	($r0,"8($ctx)");
	stg	($r0,"16($ctx)");

	&{$z? \&clgr :\&clr}  ($inp,$r0);

	je		(LABEL("Lno_key"));

	lrvg	($wr2,"0($inp)");		# load little-endian key
	lrvg	($wr3,"8($inp)");

	nihl	($wr1,0xffc0);		# 0xffffffc0ffffffff
	srlg	($r0,$wr1,4);		# 0x0ffffffc0fffffff
	srlg	($wr1,$wr1,4);
	nill	($wr1,0xfffc);		# 0x0ffffffc0ffffffc

	ngr	($wr2,$r0);
	ngr	($wr3,$wr1);

	stg	($wr2,"32($ctx)");
	stg	($wr3,"40($ctx)");

LABEL("Lno_key:");
	lghi	($rv,0);
FUNCTION_END("poly1305_init",$rv);
}

{
# static void poly1305_blocks(void *ctx, const unsigned char *inp,
#                             size_t len, u32 padbit)

my ($d0hi,$d0lo,$d1hi,$d1lo,$t0,$h0,$t1,$h1,$h2);
my $s1;
if ($flavour =~/linux/) {
	($d0hi,$d0lo,$d1hi,$d1lo,$t0,$h0,$t1,$h1,$h2) = map("%r$_",(6..14));
	$s1 = "%r2";
} else {
	($d0hi,$d0lo,$d1hi,$d1lo,$t0,$h0,$t1,$h1,$h2) = map("R$_",(6..14));
	$s1 = "R2";
}


FUNCTION_BEGIN("poly1305_blocks",4,"true");		# 4 params, Local storage
if ($flavour =~ /linux/) {
	if ($z) {
		srlg ($len, $len,4);
	} else {
		srl ($len,4);
	}

	lghi	($r0,0);
	&{$z? \&clgr :\&clr}	($len,$r0);
	je		(LABEL("Lno_data"));
		
	&{$z? \&stmg:\&stm} ("%r6","%r14","6*$SIZE_T($sp)");
} else {
	# len is in R3 on z/OS will move into R4 after test, stack is setup and R4 (DSA ptr) is saved.
	if ($z) {
		srlg ("R3","R3",4);		 
	} else {
		srl ("R3",4);
	}

	lghi	($r0,0);
	&{$z? \&clgr :\&clr}	("R3",$r0);
	je		(LABEL("Lno_data"));

	# z/OS: establish stack, move parms to appropriate regs
	la      ($sp,"STACK");
	&{$z? \&stg:\&st}	("R4","4*$SIZE_T($sp)"); # Store R4 before it is corrupted 
	&{$z? \&lg:\&l}	("R9","$DSA_OFF(R4)");      # Get DSA address, before corrupting R4	
	lgr		($len,"R3");
	lgr		($inp,"R2");
	lgr		($ctx,"R1");
	&{$z? \&lg:\&l}	($padbit,"$PARMS_OFF+$SIZE_T*3(R9)"); # Get padbit from DSA
}	

	llgfr   ($padbit,$padbit);		# clear upper half, much needed with non-64-bit ABI
	lg		($r0,"32($ctx)");		# load key
	lg		($r1,"40($ctx)");

	lg		($h0,"0($ctx)");		# load hash value
	lg		($h1,"8($ctx)");
	lg		($h2,"16($ctx)");

	&{$z ? \&stg : \&st } ($ctx,"2*$SIZE_T($sp)");

	srlg	($s1,$r1,2);
	algr	($s1,$r1);			# s1 = r1 + r1>>2
	j		(LABEL("Loop"));

ALIGN(16);
LABEL("Loop:");
	lrvg	($d0lo,"0($inp)");		# load little-endian input
	lrvg	($d1lo,"8($inp)");
	la		($inp,"16($inp)");

	algr	($d0lo,$h0);		# accumulate input
	alcgr	($d1lo,$h1);

	lgr	($h0,$d0lo);
	mlgr	($d0hi,$r0);		# h0*r0	  -> $d0hi:$d0lo
	lgr	($h1,$d1lo);
	mlgr	($d1hi,$s1);		# h1*5*r1 -> $d1hi:$d1lo

	mlgr	($t0,$r1);			# h0*r1   -> $t0:$h0
	mlgr	($t1,$r0);			# h1*r0   -> $t1:$h1
	alcgr	($h2,$padbit);

	algr	($d0lo,$d1lo);
	lgr	($d1lo,$h2);
	alcgr	($d0hi,$d1hi);
	lghi	($d1hi,0);

	algr	($h1,$h0);
	alcgr	($t1,$t0);

	msgr	($d1lo,$s1);		# h2*s1
	msgr	($h2,$r0);			# h2*r0

	algr	($h1,$d1lo);
	alcgr	($t1,$d1hi);		# $d1hi is zero

	algr	($h1,$d0hi);
	alcgr	($h2,$t1);

	lghi	($h0,-4);			# final reduction step
	ngr	($h0,$h2);
	srlg	($t0,$h2,2);
	algr	($h0,$t0);
	lghi	($t1,3);
	ngr	($h2,$t1);

	algr	($h0,$d0lo);
	alcgr	($h1,$d1hi);		# $d1hi is still zero
	alcgr	($h2,$d1hi);		# $d1hi is still zero

	&{$z ? \&brctg : \&brct} ($len,LABEL("Loop"));
	&{$z ? \&lg : \&l } ($ctx,"2*$SIZE_T($sp)");


	stg	($h0,"0($ctx)");		# store hash value
	stg	($h1,"8($ctx)");
	stg	($h2,"16($ctx)");
	
if ($flavour =~/linux/) {
	&{$z? \&lmg:\&lm}	("%r6","%r14","6*$SIZE_T($sp)");
} else {	
	&{$z? \&lg:\&l}		("R4","4*$SIZE_T($sp)"); # Restore R4 so DSA can be accessed
}
LABEL("Lno_data:");
FUNCTION_END("poly1305_blocks",$rv);
}


{
################
# static void poly1305_emit(void *ctx, unsigned char mac[16],
#                           const u32 nonce[4])

my ($ctx,$mac,$nonce);
my ($h0,$h1,$h2,$d0,$d1);
my $wr1;
if ($flavour =~ /linux/) {
	($ctx,$mac,$nonce)=map("%r$_",(2..4));
	($h0,$h1,$h2,$d0,$d1)=map("%r$_",(5..9));
	$wr1="%r1";
} else {
	($ctx,$mac,$nonce)=map("R$_",(1..3));
	($h0,$h1,$h2,$d0,$d1)=map("R$_",(5..9));
	$wr1="R11";		# ctx is in r1, use r11 instead
}

FUNCTION_BEGIN("poly1305_emit",3);
	&{$z ? \&stmg : \&stm} 	("%r6","%r9","6*$SIZE_T($sp)") if ($flavour =~ /linux/);


	lg		($h0,"0($ctx)");
	lg		($h1,"8($ctx)");
	lg		($h2,"16($ctx)");

	lghi	($r0,5);
	lghi	($wr1,0);
	lgr	($d0,$h0);
	lgr	($d1,$h1);

	algr	($h0,$r0);			# compare to modulus
	alcgr	($h1,$wr1);
	alcgr	($h2,$wr1);

	srlg	($h2,$h2,2);		# did it borrow/carry?
	slgr	($wr1,$h2);			# 0-$h2>>2
	lg		($h2,"0($nonce)");		# load nonce
	lghi	($r0,-1);
	lg		($ctx,"8($nonce)");
	xgr	($r0,$wr1);			# ~%r1

	ngr	($h0,$wr1);
	ngr	($d0,$r0);
	ngr	($h1,$wr1);
	ngr	($d1,$r0);
	ogr	($h0,$d0);
	rllg	($d0,$h2,32);		# flip nonce words
	ogr	($h1,$d1);
	rllg	($d1,$ctx,32);

	algr	($h0,$d0);			# accumulate nonce
	alcgr	($h1,$d1);

	strvg	($h0,"0($mac)");		# write little-endian result
	strvg	($h1,"8($mac)");
	&{$z ? \&lmg : \&lm} ("%r6","%r9","6*$SIZE_T($sp)") if ($flavour =~ /linux/);

FUNCTION_END("poly1305_emit",$rv);
}

ASCIZ("Poly1305 for s390x, CRYPTOGAMS by <appro\@openssl.org>");

LOCAL_VARS_BEGIN();
   ds		("STACKSPACE","178F");
   ds		("STACK", "0F");
   ds		("SAVEAREA","32F");
LOCAL_VARS_END();

PERLASM_END();

