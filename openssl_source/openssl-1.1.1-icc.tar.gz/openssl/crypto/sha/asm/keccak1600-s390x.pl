#!/usr/bin/env perl
# Copyright 2017-2018 The OpenSSL Project Authors. All Rights Reserved.
#
# Licensed under the OpenSSL license (the "License").  You may not use
# this file except in compliance with the License.  You can obtain a copy
# in the file LICENSE in the source distribution or at
# https://www.openssl.org/source/license.html
#
# ====================================================================
# Written by Andy Polyakov <appro@openssl.org> for the OpenSSL
# project. The module is, however, dual licensed under OpenSSL and
# CRYPTOGAMS licenses depending on where you obtain it. For further
# details see http://www.openssl.org/~appro/cryptogams/.
# ====================================================================
#
# Keccak-1600 for s390x.
#
# June 2017.
#
# Below code is [lane complementing] KECCAK_2X implementation (see
# sha/keccak1600.c) with C[5] and D[5] held in register bank. Though
# instead of actually unrolling the loop pair-wise I simply flip
# pointers to T[][] and A[][] at the end of round. Since number of
# rounds is even, last round writes to A[][] and everything works out.
# In the nutshell it's transliteration of x86_64 module, because both
# architectures have similar capabilities/limitations. Performance
# measurement is problematic as I don't have access to an idle system.
# It looks like z13 processes one byte [out of long message] in ~14
# cycles. At least the result is consistent with estimate based on
# amount of instruction and assumed instruction issue rate. It's ~2.5x
# faster than compiler-generated code.
use strict;
use FindBin qw($Bin);
use lib "$Bin/../..";
use perlasm::s390x qw(:MSA :DEFAULT :VX :LD AUTOLOAD LABEL INCLUDE FUNCTION_BEGIN LOCAL_FUNCTION FUNCTION_END LOCAL_FUNCTION_END OBJECT_BEGIN OBJECT_END BYTE LONG QUAD ALIGN ASCIZ TEXT GET_EXTERN LOCAL_VARS_BEGIN LOCAL_VARS_END ds);


my $output;
my ($z,$SIZE_T,$DSA_OFF,$PARMS_OFF,$g);
my ($ra,$rv,$sp);
my ($acc,$cnt,$key,$len,$inp,$out,@XX,@TX,$YY,$TY);
my ($i,$idx,$dat,$ikey,$iinp,$src,$dst,$iotas);
my (@A,@C,@D,@T,$sp,$stdframe,$frame); 
my ($wr0,$wr1,$wr6,$wr14,$wr15);				# work registers
my $flavour = shift;

$DSA_OFF=2048;
if ($flavour =~ /3[12]/) {
	$SIZE_T=4;
	$z = 0;  # 31/32 bit ABI
	$PARMS_OFF=2112;
} else {
	$SIZE_T=8;
	$z=1;    # 64 bit ABI
	$PARMS_OFF=2176;
}

while (($output=shift) && ($output!~/\w[\w\-]*\.\w+$/)) {}
open STDOUT,">$output";

PERLASM_BEGIN($flavour,$output);	

if($flavour =~ /linux/) {
	@A = map([ 8*$_, 8*($_+1), 8*($_+2), 8*($_+3), 8*($_+4) ], (0,5,10,15,20));
	@C = map("%r$_",(0,1,5..7));
	@D = map("%r$_",(8..12));
	@T = map("%r$_",(13..14));
	($src,$dst,$iotas) = map("%r$_",(2..4));
	($wr0,$wr1,$wr6,$wr14,$wr15) = map("%r$_",(0..1,6,14,15));
	$rv = "%r2";
	$ra = "%r14";
	$sp = "%r15";
} else {
	@A = map([ 8*$_, 8*($_+1), 8*($_+2), 8*($_+3), 8*($_+4) ], (0,5,10,15,20));
	@C = map("R$_",(0,1,5..7));
	@D = map("R$_",(8..12));
	@T = map("R$_",(13..14));
	($src,$dst,$iotas) = map("R$_",(2..4));
	($wr0,$wr1,$wr6,$wr14,$wr15) = map("R$_",(0..1,6,14,15));
	$rv = "R3";
	$ra = "R7";
	$sp = "R15";
}

$stdframe=16*$SIZE_T+4*8;
$frame=$stdframe+25*8;

my @rhotates = ([  0,  1, 62, 28, 27 ],
                [ 36, 44,  6, 55, 20 ],
                [  3, 10, 43, 25, 39 ],
                [ 41, 45, 15, 21,  8 ],
                [ 18,  2, 61, 56, 14 ]);

				 

{ 
	my @C = @C;	# copy, because we mess them up...
  	my @D = @D;


TEXT();
# void __KeccakF1600(uint64_t A[5][5]) ;

LOCAL_FUNCTION("__KeccakF1600");

&{$z? \&stg:\&st}	($ra,"$SIZE_T*14($sp)");
	lg		(@C[0],"$A[4][0]($src)");
	lg		(@C[1],"$A[4][1]($src)");
	lg		(@C[2],"$A[4][2]($src)");
	lg		(@C[3],"$A[4][3]($src)");
	lg		(@C[4],"$A[4][4]($src)");
	larl	($iotas,LABEL("iotas"));
	j		(LABEL("Loop"));

	ALIGN(16);
	LABEL("Loop:");
	lg		(@D[0],"$A[0][0]($src)");
	lg		(@D[1],"$A[1][1]($src)");
	lg		(@D[2],"$A[2][2]($src)");
	lg		(@D[3],"$A[3][3]($src)");

	xgr		(@C[0],@D[0]);
	xg		(@C[1],"$A[0][1]($src)");
	xg		(@C[2],"$A[0][2]($src)");
	xg		(@C[3],"$A[0][3]($src)");
	lgr		(@D[4],@C[4]);
	xg		(@C[4],"$A[0][4]($src)");

	xg		(@C[0],"$A[1][0]($src)");
	xgr		(@C[1],@D[1]);
	xg		(@C[2],"$A[1][2]($src)");
	xg		(@C[3],"$A[1][3]($src)");
	xg		(@C[4],"$A[1][4]($src)");

	xg		(@C[0],"$A[2][0]($src)");
	xg		(@C[1],"$A[2][1]($src)");
	xgr		(@C[2],@D[2]);
	xg		(@C[3],"$A[2][3]($src)");
	xg		(@C[4],"$A[2][4]($src)");

	xg		(@C[0],"$A[3][0]($src)");
	xg		(@C[1],"$A[3][1]($src)");
	xg		(@C[2],"$A[3][2]($src)");
	xgr		(@C[3],@D[3]);
	xg		(@C[4],"$A[3][4]($src)");

	lgr		(@T[0],@C[2]);
	rllg	(@C[2],@C[2],1);
	xgr		(@C[2],@C[0]);		# D[1] = ROL64(C[2], 1) ^ C[0]

	rllg	(@C[0],@C[0],1);
	xgr		(@C[0],@C[3]);		# D[4] = ROL64(C[0], 1) ^ C[3]

	rllg	(@C[3],@C[3],1);
	xgr		(@C[3],@C[1]);		# D[2] = ROL64(C[3], 1) ^ C[1]

	rllg	(@C[1],@C[1],1);
	xgr		(@C[1],@C[4]);		# D[0] = ROL64(C[1], 1) ^ C[4]

	rllg	(@C[4],@C[4],1);
	xgr		(@C[4],@T[0]);		# Ddir[3] = ROL64(C[4], 1) ^ C[2]

	(@D[0..4], @C) = (@C[1..4,0], @D);

	xgr		(@C[1],@D[1]);
	xgr		(@C[2],@D[2]);
	xgr		(@C[3],@D[3]);
	rllg	(@C[1],@C[1],"$rhotates[1][1]");
	xgr		(@C[4],@D[4]);
	rllg	(@C[2],@C[2],"$rhotates[2][2]");
	xgr		(@C[0],@D[0]);

	lgr		(@T[0],@C[1]);
	ogr		(@C[1],@C[2]);
	rllg	(@C[3],@C[3],"$rhotates[3][3]");
	xgr		(@C[1],@C[0]);		#	    C[0] ^ ( C[1] | C[2])
	rllg	(@C[4],@C[4],"$rhotates[4][4]");
	xg		(@C[1],"0($iotas)");
	la		($iotas,"8($iotas)");
	stg		(@C[1],"$A[0][0]($dst)");	# R[0][0] = C[0] ^ ( C[1] | C[2]) ^ iotas[i]

	lgr		(@T[1],@C[4]);
	ngr		(@C[4],@C[3]);
	lghi	(@C[1],-1);		# no 'not' instruction :-(
	xgr		(@C[4],@C[2]);		#	    C[2] ^ ( C[4] & C[3])
	xgr		(@C[2],@C[1]);		# not	@C[2]
	stg		(@C[4],"$A[0][2]($dst)");	# R[0][2] = C[2] ^ ( C[4] & C[3])
	ogr		(@C[2],@C[3]);
	xgr		(@C[2],@T[0]);		#	    C[1] ^ (~C[2] | C[3])

	ngr		(@T[0],@C[0]);
	stg		(@C[2],"$A[0][1]($dst)");	# R[0][1] = C[1] ^ (~C[2] | C[3])
	xgr		(@T[0],@T[1]);		#	    C[4] ^ ( C[1] & C[0])
	ogr		(@T[1],@C[0]);
	stg		(@T[0],"$A[0][4]($dst)");	# R[0][4] = C[4] ^ ( C[1] & C[0])
	xgr		(@T[1],@C[3]);		#	    C[3] ^ ( C[4] | C[0])
	stg		(@T[1],"$A[0][3]($dst)");	# R[0][3] = C[3] ^ ( C[4] | C[0])


	lg		(@C[0],"$A[0][3]($src)");
	lg		(@C[4],"$A[4][2]($src)");
	lg		(@C[3],"$A[3][1]($src)");
	lg		(@C[1],"$A[1][4]($src)");
	lg		(@C[2],"$A[2][0]($src)");

	xgr		(@C[0],@D[3]);
	xgr		(@C[4],@D[2]);
	rllg	(@C[0],@C[0],"$rhotates[0][3]");
	xgr		(@C[3],@D[1]);
	rllg	(@C[4],@C[4],"$rhotates[4][2]");
	xgr		(@C[1],@D[4]);
	rllg	(@C[3],@C[3],"$rhotates[3][1]");
	xgr		(@C[2],@D[0]);

	lgr		(@T[0],@C[0]);
	ogr		(@C[0],@C[4]);
	rllg	(@C[1],@C[1],"$rhotates[1][4]");
	xgr		(@C[0],@C[3]);		#	    C[3] ^ (C[0] |  C[4])
	rllg	(@C[2],@C[2],"$rhotates[2][0]");
	stg		(@C[0],"$A[1][3]($dst)");	# R[1][3] = C[3] ^ (C[0] |  C[4])

	lgr		(@T[1],@C[1]);
	ngr		(@C[1],@T[0]);
	lghi	(@C[0],-1);		# no 'not' instruction :-(
	xgr		(@C[1],@C[4]);		#	    C[4] ^ (C[1] &  C[0])
	xgr		(@C[4],@C[0]);		# not	@C[4]
	stg		(@C[1],"$A[1][4]($dst)");	# R[1][4] = C[4] ^ (C[1] &  C[0])

	ogr		(@C[4],@C[3]);
	xgr		(@C[4],@C[2]);		#	    C[2] ^ (~C[4] | C[3])

	ngr		(@C[3],@C[2]);
	stg		(@C[4],"$A[1][2]($dst)");	# R[1][2] = C[2] ^ (~C[4] | C[3])
	xgr		(@C[3],@T[1]);		#	    C[1] ^ (C[3] &  C[2])
	ogr		(@T[1],@C[2]);
	stg		(@C[3],"$A[1][1]($dst)");	# R[1][1] = C[1] ^ (C[3] &  C[2])
	xgr		(@T[1],@T[0]);		#	    C[0] ^ (C[1] |  C[2])
	stg		(@T[1],"$A[1][0]($dst)");	# R[1][0] = C[0] ^ (C[1] |  C[2])


	lg		(@C[2],"$A[2][3]($src)");
	lg		(@C[3],"$A[3][4]($src)");
	lg		(@C[1],"$A[1][2]($src)");
	lg		(@C[4],"$A[4][0]($src)");
	lg		(@C[0],"$A[0][1]($src)");

	xgr		(@C[2],@D[3]);
	xgr		(@C[3],@D[4]);
	rllg	(@C[2],@C[2],"$rhotates[2][3]");
	xgr		(@C[1],@D[2]);
	rllg	(@C[3],@C[3],"$rhotates[3][4]");
	xgr		(@C[4],@D[0]);
	rllg	(@C[1],@C[1],"$rhotates[1][2]");
	xgr		(@C[0],@D[1]);

	lgr		(@T[0],@C[2]);
	ngr		(@C[2],@C[3]);
	rllg	(@C[4],@C[4],"$rhotates[4][0]");
	xgr		(@C[2],@C[1]);		#	     C[1] ^ ( C[2] & C[3])
	lghi	(@T[1],-1);	# no 'not' instruction :-(
	stg		(@C[2],"$A[2][1]($dst)");	# R[2][1] =  C[1] ^ ( C[2] & C[3])

	xgr		(@C[3],@T[1]);		# not	@C[3]
	lgr		(@T[1],@C[4]);
	ngr		(@C[4],@C[3]);
	rllg	(@C[0],@C[0],"$rhotates[0][1]");
	xgr		(@C[4],@T[0]);		#	     C[2] ^ ( C[4] & ~C[3])
	ogr		(@T[0],@C[1]);
	stg		(@C[4],"$A[2][2]($dst)");	# R[2][2] =  C[2] ^ ( C[4] & ~C[3])
	xgr		(@T[0],@C[0]);		#	     C[0] ^ ( C[2] | C[1])

	ngr		(@C[1],@C[0]);
	stg		(@T[0],"$A[2][0]($dst)");	# R[2][0] =  C[0] ^ ( C[2] | C[1])
	xgr		(@C[1],@T[1]);		#	     C[4] ^ ( C[1] & C[0])
	ogr		(@C[0],@T[1]);
	stg		(@C[1],"$A[2][4]($dst)");	# R[2][4] =  C[4] ^ ( C[1] & C[0])
	xgr		(@C[0],@C[3]);		#	    ~C[3] ^ ( C[0] | C[4])
	stg		(@C[0],"$A[2][3]($dst)");	# R[2][3] = ~C[3] ^ ( C[0] | C[4])


	lg		(@C[2],"$A[2][1]($src)");
	lg		(@C[3],"$A[3][2]($src)");
	lg		(@C[1],"$A[1][0]($src)");
	lg		(@C[4],"$A[4][3]($src)");
	lg		(@C[0],"$A[0][4]($src)");

	xgr		(@C[2],@D[1]);
	xgr		(@C[3],@D[2]);
	rllg	(@C[2],@C[2],"$rhotates[2][1]");
	xgr		(@C[1],@D[0]);
	rllg	(@C[3],@C[3],"$rhotates[3][2]");
	xgr		(@C[4],@D[3]);
	rllg	(@C[1],@C[1],"$rhotates[1][0]");
	xgr		(@C[0],@D[4]);
	rllg	(@C[4],@C[4],"$rhotates[4][3]");

	lgr		(@T[0],@C[2]);
	ogr		(@C[2],@C[3]);
	lghi	(@T[1],-1);			# no 'not' instruction :-(
	xgr		(@C[2],@C[1]);		#	     C[1] ^ ( C[2] | C[3])
	xgr		(@C[3],@T[1]);		# not	@C[3]
	stg		(@C[2],"$A[3][1]($dst)");	# R[3][1] =  C[1] ^ ( C[2] | C[3])

	lgr		(@T[1],@C[4]);
	ogr		(@C[4],@C[3]);
	rllg	(@C[0],@C[0],"$rhotates[0][4]");
	xgr		(@C[4],@T[0]);				#	     C[2] ^ ( C[4] | ~C[3])
	ngr		(@T[0],@C[1]);
	stg		(@C[4],"$A[3][2]($dst)");	# R[3][2] =  C[2] ^ ( C[4] | ~C[3])
	xgr		(@T[0],@C[0]);				#	     C[0] ^ ( C[2] & C[1])

	ogr		(@C[1],@C[0]);
	stg		(@T[0],"$A[3][0]($dst)");	# R[3][0] =  C[0] ^ ( C[2] & C[1])
	xgr		(@C[1],@T[1]);				#	     C[4] ^ ( C[1] | C[0])
	ngr		(@C[0],@T[1]);
	stg		(@C[1],"$A[3][4]($dst)");	# R[3][4] =  C[4] ^ ( C[1] | C[0])
	xgr		(@C[0],@C[3]);				#	    ~C[3] ^ ( C[0] & C[4])
	stg		(@C[0],"$A[3][3]($dst)");	# R[3][3] = ~C[3] ^ ( C[0] & C[4])


	xg		(@D[2],"$A[0][2]($src)");
	xg		(@D[3],"$A[1][3]($src)");
	xg		(@D[1],"$A[4][1]($src)");
	xg		(@D[4],"$A[2][4]($src)");
	xgr		($dst,$src);		# xchg	$dst,$src
	rllg	(@D[2],@D[2],"$rhotates[0][2]");
	xg		(@D[0],"$A[3][0]($src)");
	rllg	(@D[3],@D[3],"$rhotates[1][3]");
	xgr		($src,$dst);
	rllg	(@D[1],@D[1],"$rhotates[4][1]");
	xgr		($dst,$src);
	rllg	(@D[4],@D[4],"$rhotates[2][4]");

	@C = @D[2..4,0,1];

	lgr		(@T[0],@C[0]);
	ngr		(@C[0],@C[1]);
	lghi	(@T[1],-1);		# no 'not' instruction :-(
	xgr		(@C[0],@C[4]);		#	     C[4] ^ ( C[0] & C[1])
	xgr		(@C[1],@T[1]);		# not	@C[1]
	stg		(@C[0],"$A[4][4]($src)");	# R[4][4] =  C[4] ^ ( C[0] & C[1])

	lgr		(@T[1],@C[2]);
	ngr		(@C[2],@C[1]);
	rllg	(@D[0],@D[0],"$rhotates[3][0]");
	xgr		(@C[2],@T[0]);		#	     C[0] ^ ( C[2] & ~C[1])
	ogr		(@T[0],@C[4]);
	stg		(@C[2],"$A[4][0]($src)");	# R[4][0] =  C[0] ^ ( C[2] & ~C[1])
	xgr		(@T[0],@C[3]);		#	     C[3] ^ ( C[0] | C[4])

	ngr		(@C[4],@C[3]);
	stg		(@T[0],"$A[4][3]($src)");	# R[4][3] =  C[3] ^ ( C[0] | C[4])
	xgr		(@C[4],@T[1]);		#	     C[2] ^ ( C[4] & C[3])
	ogr		(@C[3],@T[1]);
	stg		(@C[4],"$A[4][2]($src)");	# R[4][2] =  C[2] ^ ( C[4] & C[3])
	xgr		(@C[3],@C[1]);		#	    ~C[1] ^ ( C[2] | C[3])

	lgr		(@C[1],@C[0]);		# harmonize with the loop top
	lgr		(@C[0],@T[0]);
	stg		(@C[3],"$A[4][1]($src)");	# R[4][1] = ~C[1] ^ ( C[2] | C[3])

	tmll	($iotas,255);
	jnz		(LABEL("Loop"));
&{$z? \&lg:\&l}	($ra,"$SIZE_T*14($sp)");
	LOCAL_FUNCTION_END("__KeccakF1600");
}

#
# static void KeccakF1600(uint64_t A[5][5])
#
{
LOCAL_FUNCTION("KeccakF1600");
LABEL("LKeccakF1600:");
	lghi	($wr1,-$frame);
&{$z? \&stmg:\&stm}	($wr6,$wr15,"$SIZE_T*6($sp)");
	lgr		($wr0,$sp);
	la		($sp,"0($wr1,$sp)");
&{$z? \&stg:\&st}	($wr0,"0($sp)");	

	lghi	(@D[0],-1);		# no 'not' instruction :-(
	lghi	(@D[1],-1);
	lghi	(@D[2],-1);
	lghi	(@D[3],-1);
	lghi	(@D[4],-1);
	lghi	(@T[0],-1);
	xg		(@D[0],"$A[0][1]($src)");
	xg		(@D[1],"$A[0][2]($src)");
	xg		(@D[2],"$A[1][3]($src)");
	xg		(@D[3],"$A[2][2]($src)");
	xg		(@D[4],"$A[3][2]($src)");
	xg		(@T[0],"$A[4][0]($src)");
	stmg	(@D[0],@D[1],"$A[0][1]($src)");
	stg		(@D[2],"$A[1][3]($src)");
	stg		(@D[3],"$A[2][2]($src)");
	stg		(@D[4],"$A[3][2]($src)");
	stg		(@T[0],"$A[4][0]($src)");

	la		($dst,"$stdframe($sp)");

	bras	($ra,"__KeccakF1600");

	lghi	(@D[0],-1);		# no 'not' instruction :-(
	lghi	(@D[1],-1);
	lghi	(@D[2],-1);
	lghi	(@D[3],-1);
	lghi	(@D[4],-1);
	lghi	(@T[0],-1);
	xg		(@D[0],"$A[0][1]($src)");
	xg		(@D[1],"$A[0][2]($src)");
	xg		(@D[2],"$A[1][3]($src)");
	xg		(@D[3],"$A[2][2]($src)");
	xg		(@D[4],"$A[3][2]($src)");
	xg		(@T[0],"$A[4][0]($src)");
	stmg	(@D[0],@D[1],"$A[0][1]($src)");
	stg		(@D[2],"$A[1][3]($src)");
	stg		(@D[3],"$A[2][2]($src)");
	stg		(@D[4],"$A[3][2]($src)");
	stg		(@T[0],"$A[4][0]($src)");
&{$z? \&lmg:\&lm}	($wr6,$wr15,"$frame+6*$SIZE_T($sp)");
LOCAL_FUNCTION_END("KeccakF1600");
}


# 
#size_t SHA3_absorb(uint64_t A[5][5], const unsigned char *inp, size_t len,size_t r);
#
{
	FUNCTION_BEGIN("SHA3_absorb", 4, "true");
	my ($A_flat,$inp,$len,$bsz);		# parm regs
	
	
if ($flavour =~ /linux/) {
	($A_flat,$inp,$len,$bsz) = map("%r$_",(2..5));

} else {
	($A_flat,$inp,$len,$bsz) = map("R$_",(2..5));
	
  	la      ($sp,"STACK");								# Setup stack for z/OS

	&{$z? \&lg:\&l}   ("R9","$DSA_OFF(R4)");   			# Get callers DSA address
	&{$z? \&stg:\&st} ("R4","0*$SIZE_T($sp)");			# save DSA on stack
	
	&{$z? \&lgr:\&lr} ($len,"R3");						# Move p3 into $len reg which is R4, the DSA reg, it is now corrupted and will have to be restored
  	&{$z? \&lgr:\&lr} ($inp,"R2");						# Move p2 into $out reg
  	&{$z? \&lgr:\&lr} ($A_flat,"R1");					# Move p1 into $A_flat reg
	
	&{$z? \&lg:\&l}   ($bsz,"$PARMS_OFF+$SIZE_T*3(R9)");	# Get $bsz
}
	

	lghi	($wr1,-$frame);
if ($flavour =~ /linux/) {	
	&{$z? \&stmg:\&stm}	("%r5","%r15","$SIZE_T*5($sp)");
} else {
	&{$z? \&stg:\&st}	("R5","$SIZE_T*5($sp)");
}	
	lgr		($wr0,$sp);
	la		($sp,"0($wr1,$sp)");
&{$z? \&stg:\&st}	($wr0,"0($sp)");
	lghi	(@D[0],-1);		# no 'not' instruction :-(
	lghi	(@D[1],-1);
	lghi	(@D[2],-1);
	lghi	(@D[3],-1);
	lghi	(@D[4],-1);
	lghi	(@T[0],-1);
	xg		(@D[0],"$A[0][1]($src)");
	xg		(@D[1],"$A[0][2]($src)");
	xg		(@D[2],"$A[1][3]($src)");
	xg		(@D[3],"$A[2][2]($src)");
	xg		(@D[4],"$A[3][2]($src)");
	xg		(@T[0],"$A[4][0]($src)");
	stmg	(@D[0],"@D[1]","$A[0][1]($src)");
	stg		(@D[2],"$A[1][3]($src)");
	stg		(@D[3],"$A[2][2]($src)");
	stg		(@D[4],"$A[3][2]($src)");
	stg		(@T[0],"$A[4][0]($src)");

LABEL("Loop_absorb:");
&{$z? \&clgr:\&clr}	($len,$bsz);
	jl		(LABEL("Ldone_absorb"));
	if ($flavour =~ /3[12]/) {
		srl		($bsz,3);
	} else {
		srlg	($bsz,$bsz,3);
	}
	la		($wr1,"0($A_flat)");

LABEL("Lblock_absorb:");
	lrvg	($wr0,"0($inp)");
	la		($inp,"8($inp)");
	xg		($wr0,"0($wr1)");
&{$z? \&aghi:\&ahi}	($len,-8);
	stg		($wr0,"0($wr1)");
	la		($wr1,"8($wr1)");
	brct	($bsz,LABEL("Lblock_absorb"));

&{$z? \&stmg:\&stm}	($inp,$len,"$frame+3*$SIZE_T($sp)");
	la		($dst,"$stdframe($sp)");
	bras	($ra,"__KeccakF1600"); # Fix for z/OS
&{$z? \&lmg:\&lm}	($inp,$bsz,"$frame+3*$SIZE_T($sp)");
	j	(LABEL("Loop_absorb"));

	ALIGN(16);
LABEL("Ldone_absorb:");
	lghi	(@D[0],-1);		# no 'not' instruction :-(
	lghi	(@D[1],-1);
	lghi	(@D[2],-1);
	lghi	(@D[3],-1);
	lghi	(@D[4],-1);
	lghi	(@T[0],-1);
	xg		(@D[0],"$A[0][1]($src)");
	xg		(@D[1],"$A[0][2]($src)");
	xg		(@D[2],"$A[1][3]($src)");
	xg		(@D[3],"$A[2][2]($src)");
	xg		(@D[4],"$A[3][2]($src)");
	xg		(@T[0],"$A[4][0]($src)");
	stmg	(@D[0],@D[1],"$A[0][1]($src)");
	stg		(@D[2],"$A[1][3]($src)");
	stg		(@D[3],"$A[2][2]($src)");
	stg		(@D[4],"$A[3][2]($src)");
	stg		(@T[0],"$A[4][0]($src)");

	lgr	($rv,$len);		# set return value
if ($flavour =~ /linux/) {
	&{$z? \&lmg:\&lm}	("%r6","%r15","$frame+6*$SIZE_T($sp)");
} else {
	#&{$z? \&lg:\&l} ("R15","0*$SIZE_T($sp)");			# get pointer to previous sp
	#&{$z? \&lg:\&l} ("R4","0*$SIZE_T($sp)");			# get DSA off stack
	&{$z? \&lg:\&l} ("R4","$frame+0*$SIZE_T($sp)");		# get DSA off stack
}
	FUNCTION_END("SHA3_absorb",$rv);
}


#	
# void SHA3_squeeze(uint64_t A[5][5], unsigned char *out, size_t len, size_t r);
#
{ 
	FUNCTION_BEGIN("SHA3_squeeze",4,"true");
	my ($A_flat,$out,$len,$bsz);		# parm regs

if ($flavour =~ /linux/) {
	($A_flat,$out,$len,$bsz) = map("%r$_",(2..5));

} else {
	($A_flat,$out,$len,$bsz) = map("R$_",(2..5));
	
  	la      ($sp,"STACK");								# Setup stack for z/OS

	&{$z? \&lg:\&l}   ("R9","$DSA_OFF(R4)");   			# Get callers DSA address
	&{$z? \&stg:\&st} ("R4","0*$SIZE_T($sp)");			# save DSA on stack
	
	&{$z? \&lgr:\&lr} ($len,"R3");						# Move p3 into $len reg which is R4, the DSA reg, it is now corrupted and will have to be restored
  	&{$z? \&lgr:\&lr} ($out,"R2");						# Move p2 into $out reg
  	&{$z? \&lgr:\&lr} ($A_flat,"R1");					# Move p1 into $A_flat reg
	
	&{$z? \&lg:\&l}   ($bsz,"$PARMS_OFF+$SIZE_T*3(R9)");	# Get $bsz
}  	
	
if ($flavour =~ /3[12]/) {
	srl		($bsz,3);
} else {
	srlg	($bsz,$bsz,3);
}
&{$z? \&stg:\&st}	($wr14,"2*$SIZE_T($sp)") if ($flavour =~ /linux/);
	lghi	($wr14,8);
&{$z? \&stg:\&st}	($bsz,"5*$SIZE_T($sp)");
	
	la		($wr1,"0($A_flat)");	
	j		(LABEL("Loop_squeeze"));

	ALIGN(16);
LABEL("Loop_squeeze:");
&{$z? \&clgr:\&clr} ($len,$wr14);
	jl		(LABEL("Ltail_squeeze"));

	lrvg	($wr0,"0($wr1)");
	la		($wr1,"8($wr1)");
	stg		($wr0,"0($out)");
	la		($out,"8($out)");
&{$z? \&aghi:\&ahi}	($len,-8);			# len -= 8
	jz		(LABEL("Ldone_squeeze"));

	brct	($bsz,LABEL("Loop_squeeze"));	# bsz--
&{$z? \&stmg:\&stm}	($out,$len,"3*$SIZE_T($sp)");
	bras	($ra,"KeccakF1600");
&{$z? \&lmg:\&lm}	($out,$bsz,"3*$SIZE_T($sp)");
	lghi	($wr14,8);
	la		($wr1,"0($A_flat)");
	j		(LABEL("Loop_squeeze"));

LABEL("Ltail_squeeze:");
	lg		($wr0,"0($wr1)");
LABEL("Loop_tail_squeeze:");
	stc		($wr0,"0($out)");
	la		($out,"1($out)");
	srlg	($wr0,$wr0,8);
	brct	($len,LABEL("Loop_tail_squeeze"));

LABEL("Ldone_squeeze:");
if ($flavour =~ /linux/) {
	&{$z? \&lg:\&l}	($wr14,"2*$SIZE_T($sp)");
} else {
	&{$z? \&lg:\&l} ("R4","0*$SIZE_T($sp)");			# get DSA off stack
}
	FUNCTION_END("SHA3_squeeze",$rv);
}

ALIGN(256);

	QUAD(	"0","0","0","0","0","0","0","0");
	OBJECT_BEGIN("iotas",8);
	QUAD(	"0000000000000001");
	QUAD(	"0000000000008082");
	QUAD(	"800000000000808a");
	QUAD(	"8000000080008000");
	QUAD(	"000000000000808b");
	QUAD(	"0000000080000001");
	QUAD(	"8000000080008081");
	QUAD(	"8000000000008009");
	QUAD(	"000000000000008a");
	QUAD(	"0000000000000088");
	QUAD(	"0000000080008009");
	QUAD(	"000000008000000a");
	QUAD(	"000000008000808b");
	QUAD(	"800000000000008b");
	QUAD(	"8000000000008089");
	QUAD(	"8000000000008003");
	QUAD(	"8000000000008002");
	QUAD(	"8000000000000080");
	QUAD(	"000000000000800a");
	QUAD(	"800000008000000a");
	QUAD(	"8000000080008081");
	QUAD(	"8000000000008080");
	QUAD(	"0000000080000001");
	QUAD(	"8000000080008008");
	OBJECT_END("iotas");
	ASCIZ	("Keccak-1600 absorb and squeeze for s390x, CRYPTOGAMS by <appro\@openssl.org>");



# unlike 32-bit shift 64-bit one takes three arguments - will need to revisit this
# Fixed inline in the code. It's in if($flavour blocks now and done explicitly
#$code =~ s/(srlg\s+)(%r[0-9]+),/$1$2,$2,/gm;

LOCAL_VARS_BEGIN();
	ds		("STACKSPACE","180F");
    ds		("STACK", "0F");
    ds      ("SAVEAREA","32F");
LOCAL_VARS_END();

PERLASM_END();

