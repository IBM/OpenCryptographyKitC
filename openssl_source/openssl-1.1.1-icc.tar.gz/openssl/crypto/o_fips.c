/*
 * Copyright 2011-2016 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#include "internal/cryptlib.h"

static int fips_mode = 0;

int FIPS_mode(void)
{
    return fips_mode;
}

int FIPS_mode_set(int r)
{
    int rv = 1;
    if(0 == fips_mode) {
        if(r) fips_mode = 1;
    } else {    
        if(0 == r) {
            rv = 0;
        }
    }
    return rv;
}
